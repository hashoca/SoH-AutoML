% 1. Load all Cell structs
S = load('Oxford_Battery_Degradation_dataset_1.mat');

sg_window   = 7;    % SG window size
sg_order    = 3;    % SG polynomial order
window_size = 200;  % Moving window size

for i = 1:8
    cellName = sprintf('Cell%d', i);
    Cell = S.(cellName);
    cycleFields = fieldnames(Cell);

    cycles = [];
    sohs   = [];
    peaks  = [];
    meanTs = []; % Ortalama sıcaklık vektörü

    for k = 1:numel(cycleFields)
        fn = cycleFields{k};
        if startsWith(fn, 'cyc')
            % Find cycle number
            cyc_num = str2double(fn(4:end));

            % Calculate capacity and SoH
            try
                q = Cell.(fn).OCVch.q;
                qSum_all = q(end);
            catch
                continue
            end

            % For the first cycle, find reference capacity
            if isempty(sohs)
                qRef = qSum_all;
            end
            SoH = (qSum_all / qRef) * 100;

            % Check C1ch data length for IC peak analysis and mean T
            try
                qC1 = Cell.(fn).C1ch.q;
                T_C1 = Cell.(fn).C1ch.T;
                mean_T = mean(T_C1);
            catch
                peaks(end+1,1) = NaN;
                meanTs(end+1,1) = NaN;
                cycles(end+1,1) = cyc_num;
                sohs(end+1,1) = SoH;
                continue
            end

            if numel(qC1) > window_size
                idx = k; % field index
                try
                    [peak, ~, ~] = IC_analysis(Cell, idx, window_size, sg_window, sg_order);
                catch
                    peak = NaN;
                end
            else
                peak = NaN;
            end

            cycles(end+1,1) = cyc_num;
            sohs(end+1,1)   = SoH;
            peaks(end+1,1)  = peak;
            meanTs(end+1,1) = mean_T;
        end
    end

    % Sort results by cycle number
    T = table(cycles, peaks, meanTs, sohs, 'VariableNames', {'Cycle', 'Peak', 'Mean_Temperature', 'SoH'});
    T = sortrows(T, 'Cycle');

    % Save as CSV file
    csvFile = sprintf('%s_Cycle_Peak_meanT_SoH.csv', cellName);
    writetable(T, csvFile);
    fprintf('%s has been saved successfully (%d records)\n', csvFile, height(T));

end
