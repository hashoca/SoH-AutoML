function [peak, loc, dQdV_smoothed] = IC_analysis(Cell, cycleIndex, windowSize, sg_window, sg_polynomial_order)
    % IC_analysis - Bataryanın Incremental Capacity (IC) analizini yapar
    %
    %   Input:
    %       Cell - Hücre verisi (Cell1, Cell2, vb.)
    %       cycleIndex - Analiz edilecek döngü numarası (örneğin, 1, 2, 3,...)
    %       windowSize - Pencere boyutu (saniye cinsinden, örneğin 20)
    %
    %   Output:
    %       peaks - IC eğrisinin zirve noktaları (dQ/dV)
    %       locs - Zirve noktalarının konumları
    %       dQdV_smoothed - Diferansiyel kapasite eğrisinin yumuşatılmış hali (dQ/dV)

    % Döngü verilerini al
    cycleFields = fieldnames(Cell);
    cycleName = cycleFields{cycleIndex};  % Verilen döngüyü seç

    % C1ch verilerini al
    voltage = Cell.(cycleName).C1ch.v;  % Voltaj verisi
    q = Cell.(cycleName).C1ch.q/1000;  % Kümülatif kapasite verisi
    time = Cell.(cycleName).C1ch.t;  % Zaman verisi

    N = length(q);  % Veri uzunluğu

    % dQ/dV hesaplama (20 saniyelik hareketli pencereyle)
    dQdV = zeros(N - windowSize, 1);  % dQ/dV için önceden tahsis edilen dizi

    for k = 1:N - windowSize
        % 20 saniyelik pencereyi hareket ettirerek veri seç
        idxStart = k;  % Başlangıç indeksi
        idxEnd = k + windowSize - 1;  % Bitiş indeksi
        
        voltageSegment = voltage(idxStart:idxEnd);  % Voltaj segmenti
        qSegment = q(idxStart:idxEnd);  % Kapasite segmenti
        
        % dQ ve dV hesaplama
        dV = diff(voltageSegment);  % Voltaj farkları
        dQ = diff(qSegment);  % Kapasite farkları
        
        % dQ/dV hesapla
        dQdV(k) = sum(dQ) / sum(dV);  % 20 saniyelik dilimde toplam farkları alarak dQ/dV hesapla
    end

    dQdV_smoothed = sgolayfilt(dQdV, sg_polynomial_order, sg_window);  % Yumuşatma işlemi
    peak = max(dQdV_smoothed);
    loc = voltage(windowSize + find(dQdV_smoothed == max(dQdV_smoothed)));
    
end
